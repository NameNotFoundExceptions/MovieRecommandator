## Frontend for Movie Recommendations

Created using `create-react-app`
